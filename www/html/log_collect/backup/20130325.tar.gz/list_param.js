/*
function show_ror_snap_param1(data,id){
  var txt = data;
  $("#ror-snap_param1").text(txt);
}

function show_ror_snap_param2(data,id){
  var txt = data;
  $("#ror-snap_param2").text(txt);
}

function show_ror_ope_param1(data,id){
  var txt = data;
  $("#ror-ope_param1").text(txt);
}

function show_cnm_snap_param1(data,id){
  var txt = data;
  $("#cnm-snap_param1").text(txt);
}

function show_cnm_snap_param2(data,id){
  var txt = data;
  $("#cnm-snap_param2").text(txt);
}

function show_csm_snap_param1(data,id){
  var txt = data;
  $("#csm-snap_param1").text(txt);
}
*/

function show_VSYS_DB_param1(data,id){
  var txt = data;
  $("#vsys-db_param1").text(txt);
}

function show_VSYS_DB_param2(data,id){
  var txt = data;
  $("#vsys-db_param2").text(txt);
}

function show_VSYS_AP_param1(data,id){
  var txt = data;
  $("#vsys-ap_param1").text(txt);
}

function show_charge_param1(data,id){
  var txt = data;
  $("#charge_param1").text(txt);
}

function show_swcm_param3(data,id){
  var txt = data;
  $("#swcm_param3").text(txt);
}

function show_xen_param1(data,id){
  var txt = data;
  $("#xen_param1").text(txt);
}

function show_csm_agent_snap_param1(data,id){
  var txt = data;
  $("#csm-agent-snap_param1").text(txt);
}

function show_kvm_param1(data,id){
  var txt = data;
  $("#kvm_param1").text(txt);
}
